﻿namespace Repositories.DTOs
{
    public class ErrorResponseDTO
    {
        public string ErrorCode { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
    }
}